<?php 

// add your email address here
define("YOUR_MAIL", 'info@example.com');


$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
 
$to = YOUR_MAIL;
$subject = 'Message from Your site';
$message = '<br /> <br />From: '.$name.'<br /> <br /> Email: '.$email.'<br /><br /> Message: '.$message;
$headers = 'From: '.$email . "\r\n".'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
if (filter_var($email, FILTER_VALIDATE_EMAIL)) { 
  mail($to, $subject, $message, $headers); 
	echo "true"; 
}else{
	echo "false";
}

?>