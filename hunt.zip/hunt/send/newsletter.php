<?php

if($_POST){

$email = $_POST['email_n'];
//the data

$data = "$email \n";

//open the file and choose the mode

$fh = fopen("emails.txt", "a");

fwrite($fh, $data);

//close the file

fclose($fh);
echo "true"; 
}else {
echo "false"; 
}



?>
