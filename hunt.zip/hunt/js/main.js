/*

Author: Kodografia
Theme URI: http://themes.kodografia.pl/vol/demo
Author URI: http://themeforest.net/user/kodografia
Version: 1.0


1. COUNTDOWN SET
2. FULLPAGE 
3. VALIDATION FORM
4. GOOGLE MAP 
5. PRELOADER



*/

$(document).ready(function(e) {

    // 1. COUNTDOWN SET
    $('#clock').countdown('2015/02/12').on('update.countdown', function(event) {
        var $this = $(this).html(event.strftime('' + '<div class="day"><span>%-D</span> <i>day%!d</i></div>' + '<div><span>%H</span> <i>hr</i></div>' + '<div><span>%M</span> <i>min</i></div>' + '<div><span>%S</span> <i>sec</i></div>'));
    });

            


    // 2. FULLPAGE     
    var fullpage = $('#fullpage').fullpage({
        navigation: true,
        scrollingSpeed: 700,
        easing: 'easeOutBack',
        anchors: ['home', 'about', 'contact'],
        navigationTooltips: ['home', 'about', 'contact'],
        loopBottom: false,
        menu: true,
        keyboardScrolling: true,
        scrollingSpeed: 1700,
        afterResize: function() {
            deviceSettings($(window).width());
        },
        afterLoad: function(anchorLink, index) {
            $('body').removeAttr('class');
            $('body').addClass('section' + index);
        }
    });

    deviceSettings($(window).width());

    function deviceSettings(width) {
        if (width <= 800) {
            $.fn.fullpage.setAutoScrolling(false);
            $.fn.fullpage.setAllowScrolling(false);
        }
        if (width > 800) {
            $.fn.fullpage.setAutoScrolling(true);
            $.fn.fullpage.setAllowScrolling(true);
        }
    }



    // 3. VALIDATION FORM  
    function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!regex.test(email)) {
            return false;
        } else {
            return true;
        }
    }


    $("#contact-form input:submit").click(function(e) {
        $(".alert").hide();
        $("#contact-form input,#contact-form textarea").removeClass("error-i");
        var count = 0;
        if ($("#contact-form input[name='email']").val().length < 1) {
            count++;
            $("#contact-form input[name='email']").addClass("error-i");
        }
        if (count > 0) {
            $("#contact-form .error").show();
        } else {
            $.post("send/send.php", $("#contact-form").serialize(), function(response) {
                if (response == "true") {
                    $("#contact-form .success").show();
                } else {
                    $("#contact-form .error").show();
                    $("#contact-form input[name='email']").addClass("error-i");
                }
            });
        }
        return false
    });


 
    // 4. GOOGLE MAP   
    var myLatlng = new google.maps.LatLng(23.1278179,72.5462171);    //set localization
    var map; 
    var marker;
    
    function initialize() {
        var styles = 
       //cyan
       //[{"featureType":"water","elementType":"all","stylers":[{"hue":"#7fc8ed"},{"saturation":55},{"lightness":-6},{"visibility":"on"}]},{"featureType":"water","elementType":"labels","stylers":[{"hue":"#7fc8ed"},{"saturation":55},{"lightness":-6},{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"hue":"#83cead"},{"saturation":1},{"lightness":-15},{"visibility":"on"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"hue":"#f3f4f4"},{"saturation":-84},{"lightness":59},{"visibility":"on"}]},{"featureType":"landscape","elementType":"labels","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"off"}]},{"featureType":"road","elementType":"geometry","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"on"}]},{"featureType":"road","elementType":"labels","stylers":[{"hue":"#bbbbbb"},{"saturation":-100},{"lightness":26},{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"hue":"#ffcc00"},{"saturation":100},{"lightness":-35},{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"hue":"#ffcc00"},{"saturation":100},{"lightness":-22},{"visibility":"on"}]},{"featureType":"poi.school","elementType":"all","stylers":[{"hue":"#d7e4e4"},{"saturation":-60},{"lightness":23},{"visibility":"on"}]}];
       //beige
       [{"featureType":"landscape","stylers":[{"saturation":-7},{"gamma":1.02},{"hue":"#ffc300"},{"lightness":-10}]},{"featureType":"road.highway","stylers":[{"hue":"#ffaa00"},{"saturation":-45},{"gamma":1},{"lightness":-4}]},{"featureType":"road.arterial","stylers":[{"hue":"#ffaa00"},{"lightness":-10},{"saturation":64},{"gamma":0.9}]},{"featureType":"road.local","stylers":[{"lightness":-5},{"hue":"#00f6ff"},{"saturation":-40},{"gamma":0.75}]},{"featureType":"poi","stylers":[{"saturation":-30},{"lightness":11},{"gamma":0.5},{"hue":"#ff8000"}]},{"featureType":"water","stylers":[{"hue":"#0077ff"},{"gamma":1.25},{"saturation":-22},{"lightness":-31}]}];
       //pink
       //[{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"336d75"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"hue":"#1900ff"},{"color":"#d064a4"}]},{"featureType":"landscape.man_made","elementType":"geometry.fill"},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","stylers":[{"color":"#6bb1e1"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"on"},{"lightness":700}]}];
       //gray
       //[{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#d3d3d3"}]},{"featureType":"transit","stylers":[{"color":"#808080"},{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"color":"#b3b3b3"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.local","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"weight":1.8}]},{"featureType":"road.local","elementType":"geometry.stroke","stylers":[{"color":"#d7d7d7"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ebebeb"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#a7a7a7"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"landscape","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#efefef"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#696969"}]},{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"color":"#737373"}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"geometry.stroke","stylers":[{"color":"#d6d6d6"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"color":"#dadada"}]}];
       //blue
       //[{"featureType":"road.highway.controlled_access","elementType":"geometry.fill","stylers":[{"color":"#676d75"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"color":"#f8f8f8"}]},{"featureType":"landscape.man_made","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#676D75"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"color":"#cfd5db"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.fill","stylers":[{"color":"#666666"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"}]},{"featureType":"road.local","elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"geometry.stroke","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#676d75"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#585d63"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#43B7EA"}]}];
       //green
       //[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#004358"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#1f8a70"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#1f8a70"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#fd7400"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#1f8a70"},{"lightness":-20}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#1f8a70"},{"lightness":-17}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#ffffff"},{"visibility":"on"},{"weight":0.9}]},{"elementType":"labels.text.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#1f8a70"},{"lightness":-10}]},{},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#1f8a70"},{"weight":0.7}]}];
          var mapOptions = {
            zoom: 17,
            scrollwheel: false,
            center: myLatlng,
            styles: styles,
            panControl: false,
            zoomControl: false,
            mapTypeControl: false,
            scaleControl: false,
            streetViewControl: false,
            overviewMapControl: false
        }
        
        
        map = new google.maps.Map(document.getElementById('map'), mapOptions);
    }
    google.maps.event.addDomListener(window, 'load', initialize);
    $('.show-map').click(function() {

        marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            icon: {
                path: MAP_PIN,
                fillColor: '#fff',
                fillOpacity: 1,
                strokeColor: '#000',
                strokeWeight: 2,
                scale: 1 / 3
            }
        });   
        
  			var contentString = '<div id="map-content">'+
  			  '<h4>Vol</h4>'+
  			  '<p>Find us here <br /> ' +  
  			  '</p>'+
  			  '</div>';
  
    	  var infowindow = new google.maps.InfoWindow({
    			  content: contentString
    		 });
  			        
  			google.maps.event.addListener(marker, 'click', function() {
  				infowindow.open(map,marker);
  			});
    
        $('#map').addClass("show");
        $('#map').after("<a href='#contact' class='hidde-map'><i class='fa fa-times-circle'></i></a>");
        $('#fullPage-nav').hide();
        $('#map').height($(window).height()+50);
        $("body,html").css("overflow","hidden");
        google.maps.event.trigger(map, 'resize');
        map.setCenter(myLatlng); 
        //hide 
        $('.hidde-map').click(function() {
            $('#map').removeClass("show");
            $('.hidde-map').remove();
            $('#fullPage-nav').show();
            $('#map').css("height","100%");
            if($(window).width()<800)
            $("body,html").css("overflow","auto");
            google.maps.event.trigger(map, 'resize');
            map.setCenter(myLatlng);  
            marker.setMap(null);
        })
        $(document).keydown(function(e) {
            if (e.keyCode == 27) {
                $('#map').removeClass("show");
                $('.hidde-map').remove();
                $('#fullPage-nav').show();
            $('#map').css("height","100%");
            if($(window).width()<800)
            $("body,html").css("overflow","auto");
            google.maps.event.trigger(map, 'resize');
            map.setCenter(myLatlng);                 
            marker.setMap(null);
            }
        });
    })

 function setAllMap(map) {
  for (var i = 0; i < markers.length; i++) {
    markers[i].setMap(map);
  }
}

});

    // 4. PRELOADER 
  $(window).load(function() {
      $("#fullPage-nav").hide();
      $("#status").fadeOut("slow");
      $("#preloader").delay(1000).fadeOut("slow");
      $("#fullPage-nav").delay(1000).fadeIn("slow");
  })